import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // Currency exchange rate proxy endpoint (optional - frontend handles API calls directly)
  app.get("/api/exchange/:base", async (req, res) => {
    try {
      const { base } = req.params;
      const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${base}`);
      
      if (!response.ok) {
        throw new Error(`Exchange API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Exchange rate fetch error:", error);
      res.status(500).json({ 
        error: "Failed to fetch exchange rates",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(),
      service: "Multi Calculator Pro"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
