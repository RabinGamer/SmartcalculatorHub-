# Multi Calculator Pro

## Overview

Multi Calculator Pro is a comprehensive web-based calculator application that provides three main calculation modes: basic arithmetic, scientific calculations, and unit conversions. Built as a modern single-page application, it features a responsive design optimized for both desktop and mobile devices. The application includes real-time currency conversion capabilities and a dark-themed, professional interface designed for mathematical computations and unit conversions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application follows a React-based single-page application (SPA) architecture using TypeScript for type safety. The frontend is built with Vite as the build tool and bundler, providing fast development and optimized production builds. The component architecture uses a modular approach with three main calculator modes implemented as separate components.

**UI Framework**: The application uses shadcn/ui components built on top of Radix UI primitives, providing accessible and customizable UI elements. Tailwind CSS handles styling with a custom dark theme configuration optimized for calculator interfaces.

**State Management**: Local component state is managed using React hooks, with custom hooks (`useCalculator`, `useUnitConverter`) encapsulating calculator logic and state operations. TanStack Query handles API state management for currency exchange rates.

**Routing**: The application uses Wouter for lightweight client-side routing, though the current implementation is primarily a single-page interface with tab-based navigation.

### Backend Architecture
The backend follows a minimal Express.js server architecture designed to serve the frontend and provide API endpoints. The server implements a simple REST API pattern with middleware for logging and error handling.

**Server Framework**: Express.js serves as the web server with custom middleware for request logging and JSON response capture. The server is configured to handle both development and production environments.

**API Design**: RESTful endpoints provide currency exchange rate proxying and health checks. The primary API integration is with external currency exchange services.

### Data Management
**Database Schema**: The application includes Drizzle ORM configuration with PostgreSQL support, though the current implementation uses in-memory storage for user data. The schema defines a basic user table structure for potential future authentication features.

**Currency Data**: Real-time currency exchange rates are fetched from external APIs with caching mechanisms to reduce API calls and improve performance. Fallback systems handle API failures gracefully.

### Key Features Architecture
**Calculator Modes**: 
- Basic Calculator: Handles standard arithmetic operations with keyboard support
- Scientific Calculator: Extends basic functionality with trigonometric, logarithmic, and advanced mathematical functions
- Unit Converter: Supports multiple unit categories including currency, length, area, temperature, and more

**Responsive Design**: Mobile-first design approach with adaptive layouts for different screen sizes. Touch-optimized button sizes and layouts for mobile calculator usage.

**Error Handling**: Comprehensive error handling for mathematical operations (division by zero, invalid inputs) and API failures with user-friendly error messages.

## External Dependencies

### Core Technologies
- **React 18**: Frontend framework for component-based UI development
- **TypeScript**: Type safety and enhanced development experience
- **Vite**: Build tool and development server with fast HMR
- **Express.js**: Backend web server framework
- **Node.js**: Runtime environment for the backend server

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Radix UI**: Accessible UI primitives and components
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Lucide React**: Icon library for consistent iconography
- **Font Awesome**: Additional icon set for specialized calculator symbols

### State Management and Data Fetching
- **TanStack React Query**: Server state management and caching
- **React Hook Form**: Form handling and validation
- **Zod**: Schema validation library

### Database and ORM
- **Drizzle ORM**: TypeScript ORM for database operations
- **PostgreSQL**: Database system (configured but using in-memory storage currently)
- **Neon Database**: Cloud PostgreSQL provider integration

### External APIs
- **Exchange Rate API**: Primary currency exchange rate provider
- **Open Exchange Rates**: Fallback currency API service
- Real-time currency conversion with automatic fallback mechanisms

### Development and Build Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer
- **tsx**: TypeScript execution for development server

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx**: Conditional CSS class utility
- **nanoid**: Unique ID generation
- **class-variance-authority**: CSS variant utility for component styling