export function evaluateExpression(a: number, b: number, operator: string): number {
  switch (operator) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "×":
    case "*":
      return a * b;
    case "÷":
    case "/":
      if (b === 0) {
        throw new Error("Division by zero");
      }
      return a / b;
    case "^":
    case "**":
      return Math.pow(a, b);
    default:
      throw new Error(`Unknown operator: ${operator}`);
  }
}

export function isOperator(input: string): boolean {
  return ["+", "-", "×", "÷", "*", "/", "^", "**"].includes(input);
}

export function evaluateScientificFunction(func: string, value: number, angleMode: "rad" | "deg" = "rad"): number {
  // Convert degrees to radians if needed
  const toRadians = (deg: number) => (deg * Math.PI) / 180;
  const fromRadians = (rad: number) => (rad * 180) / Math.PI;

  switch (func) {
    // Basic trigonometric functions
    case "sin":
      return Math.sin(angleMode === "deg" ? toRadians(value) : value);
    case "cos":
      return Math.cos(angleMode === "deg" ? toRadians(value) : value);
    case "tan":
      return Math.tan(angleMode === "deg" ? toRadians(value) : value);
    case "asin":
      const asinResult = Math.asin(value);
      return angleMode === "deg" ? fromRadians(asinResult) : asinResult;
    case "acos":
      const acosResult = Math.acos(value);
      return angleMode === "deg" ? fromRadians(acosResult) : acosResult;
    case "atan":
      const atanResult = Math.atan(value);
      return angleMode === "deg" ? fromRadians(atanResult) : atanResult;

    // Additional trigonometric functions
    case "sec":
      const secValue = Math.cos(angleMode === "deg" ? toRadians(value) : value);
      if (Math.abs(secValue) < 1e-10) throw new Error("Division by zero in sec");
      return 1 / secValue;
    case "csc":
      const cscValue = Math.sin(angleMode === "deg" ? toRadians(value) : value);
      if (Math.abs(cscValue) < 1e-10) throw new Error("Division by zero in csc");
      return 1 / cscValue;
    case "cot":
      const cotValue = Math.tan(angleMode === "deg" ? toRadians(value) : value);
      if (Math.abs(cotValue) < 1e-10) throw new Error("Division by zero in cot");
      return 1 / cotValue;

    // Hyperbolic functions
    case "sinh":
      return Math.sinh(value);
    case "cosh":
      return Math.cosh(value);
    case "tanh":
      return Math.tanh(value);
    case "asinh":
      return Math.asinh(value);
    case "acosh":
      if (value < 1) throw new Error("Invalid input for acosh");
      return Math.acosh(value);
    case "atanh":
      if (Math.abs(value) >= 1) throw new Error("Invalid input for atanh");
      return Math.atanh(value);

    // Logarithmic functions
    case "log":
      if (value <= 0) throw new Error("Invalid input for log");
      return Math.log10(value);
    case "ln":
      if (value <= 0) throw new Error("Invalid input for ln");
      return Math.log(value);
    case "log2":
      if (value <= 0) throw new Error("Invalid input for log2");
      return Math.log2(value);

    // Power and root functions
    case "sqrt":
      if (value < 0) throw new Error("Invalid input for sqrt");
      return Math.sqrt(value);
    case "cbrt":
      return Math.cbrt(value);
    case "exp":
      return Math.exp(value);
    case "exp10":
      return Math.pow(10, value);
    case "exp2":
      return Math.pow(2, value);

    // Other mathematical functions
    case "abs":
      return Math.abs(value);
    case "inverse":
      if (value === 0) throw new Error("Division by zero");
      return 1 / value;
    case "square":
      return value * value;
    case "cube":
      return value * value * value;
    case "factorial":
      if (value < 0 || !Number.isInteger(value) || value > 170) 
        throw new Error("Invalid input for factorial");
      let result = 1;
      for (let i = 2; i <= value; i++) {
        result *= i;
      }
      return result;
    case "floor":
      return Math.floor(value);
    case "ceil":
      return Math.ceil(value);
    case "round":
      return Math.round(value);
    case "sign":
      return Math.sign(value);
    case "random":
      return Math.random();

    // Degree/Radian conversion
    case "toRad":
      return toRadians(value);
    case "toDeg":
      return fromRadians(value);

    default:
      throw new Error(`Unknown function: ${func}`);
  }
}

export const CONSTANTS = {
  pi: Math.PI,
  e: Math.E,
} as const;
