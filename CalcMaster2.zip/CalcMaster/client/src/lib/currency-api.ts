const EXCHANGE_API_KEY = import.meta.env.VITE_EXCHANGE_API_KEY || "demo_key";
const EXCHANGE_API_BASE = "https://api.exchangerate-api.com/v4/latest";

interface ExchangeRateResponse {
  base: string;
  date: string;
  rates: Record<string, number>;
}

let ratesCache: { [baseCurrency: string]: { rates: Record<string, number>; timestamp: number } } = {};
const CACHE_DURATION = 60 * 60 * 1000; // 1 hour

export async function getCurrencyRates(baseCurrency: string = "USD"): Promise<Record<string, number>> {
  // Check cache first
  const cached = ratesCache[baseCurrency];
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.rates;
  }

  try {
    // Try primary API
    const response = await fetch(`${EXCHANGE_API_BASE}/${baseCurrency}`);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data: ExchangeRateResponse = await response.json();
    
    // Cache the results
    ratesCache[baseCurrency] = {
      rates: data.rates,
      timestamp: Date.now(),
    };

    return data.rates;
  } catch (error) {
    console.warn("Primary exchange rate API failed, using fallback:", error);
    
    // Fallback: try alternative API or return mock rates
    try {
      const fallbackResponse = await fetch(`https://open.er-api.com/v6/latest/${baseCurrency}`);
      if (fallbackResponse.ok) {
        const fallbackData = await fallbackResponse.json();
        const rates = fallbackData.rates;
        
        ratesCache[baseCurrency] = {
          rates,
          timestamp: Date.now(),
        };
        
        return rates;
      }
    } catch (fallbackError) {
      console.warn("Fallback exchange rate API also failed:", fallbackError);
    }

    // Last resort: return mock rates for demo purposes
    const mockRates = getMockRates(baseCurrency);
    ratesCache[baseCurrency] = {
      rates: mockRates,
      timestamp: Date.now(),
    };
    
    return mockRates;
  }
}

function getMockRates(baseCurrency: string): Record<string, number> {
  // Mock exchange rates (approximate values for demo)
  const mockRatesFromUSD: Record<string, number> = {
    USD: 1.0,
    EUR: 0.85,
    GBP: 0.73,
    JPY: 110.0,
    AUD: 1.35,
    CAD: 1.25,
    CHF: 0.92,
    CNY: 6.45,
    INR: 74.5,
    KRW: 1180.0,
    MXN: 20.1,
    BRL: 5.2,
    RUB: 73.5,
    ZAR: 14.8,
  };

  if (baseCurrency === "USD") {
    return mockRatesFromUSD;
  }

  // Convert from USD rates to other base currency
  const baseRate = mockRatesFromUSD[baseCurrency];
  if (!baseRate) {
    throw new Error(`Mock rates not available for base currency: ${baseCurrency}`);
  }

  const convertedRates: Record<string, number> = {};
  for (const [currency, rate] of Object.entries(mockRatesFromUSD)) {
    convertedRates[currency] = rate / baseRate;
  }

  return convertedRates;
}
