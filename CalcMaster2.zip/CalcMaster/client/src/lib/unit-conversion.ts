export type UnitCategory = 
  | "currency" | "area" | "length" | "temperature" | "volume" | "mass" 
  | "data" | "speed" | "time" | "pressure" | "force" | "power" 
  | "energy" | "frequency" | "angle" | "fuel" | "age" | "numeral" 
  | "gst" | "splitbill" | "date" | "bmi" | "discount" | "loan" 
  | "fuelefficiency" | "fuelcost" | "investment" | "menstrualcycle" 
  | "bmr" | "gpa" | "worldtime" | "savings";

export interface UnitCategoryData {
  name: string;
  units: string[];
  baseUnit: string;
  conversions: Record<string, number>;
}

export const UNIT_CATEGORIES: Record<UnitCategory, UnitCategoryData> = {
  currency: {
    name: "Currency",
    units: ["USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "INR", "KRW", "MXN", "BRL", "RUB", "ZAR"],
    baseUnit: "USD",
    conversions: {}, // Dynamic from API
  },
  area: {
    name: "Area",
    units: ["Square Meter", "Square Kilometer", "Square Centimeter", "Square Millimeter", "Square Inch", "Square Foot", "Square Yard", "Acre", "Hectare"],
    baseUnit: "Square Meter",
    conversions: {
      "Square Meter": 1,
      "Square Kilometer": 0.000001,
      "Square Centimeter": 10000,
      "Square Millimeter": 1000000,
      "Square Inch": 1550.0031,
      "Square Foot": 10.7639,
      "Square Yard": 1.19599,
      "Acre": 0.000247105,
      "Hectare": 0.0001,
    },
  },
  length: {
    name: "Length",
    units: ["Meter", "Kilometer", "Centimeter", "Millimeter", "Inch", "Foot", "Yard", "Mile", "Nautical Mile"],
    baseUnit: "Meter",
    conversions: {
      "Meter": 1,
      "Kilometer": 0.001,
      "Centimeter": 100,
      "Millimeter": 1000,
      "Inch": 39.3701,
      "Foot": 3.28084,
      "Yard": 1.09361,
      "Mile": 0.000621371,
      "Nautical Mile": 0.000539957,
    },
  },
  temperature: {
    name: "Temperature",
    units: ["Celsius", "Fahrenheit", "Kelvin"],
    baseUnit: "Celsius",
    conversions: {}, // Special handling required
  },
  volume: {
    name: "Volume",
    units: ["Liter", "Milliliter", "Gallon (US)", "Gallon (UK)", "Quart", "Pint", "Cup", "Fluid Ounce", "Cubic Meter", "Cubic Centimeter"],
    baseUnit: "Liter",
    conversions: {
      "Liter": 1,
      "Milliliter": 1000,
      "Gallon (US)": 0.264172,
      "Gallon (UK)": 0.219969,
      "Quart": 1.05669,
      "Pint": 2.11338,
      "Cup": 4.22675,
      "Fluid Ounce": 33.814,
      "Cubic Meter": 0.001,
      "Cubic Centimeter": 1000,
    },
  },
  mass: {
    name: "Mass",
    units: ["Kilogram", "Gram", "Pound", "Ounce", "Ton", "Stone", "Milligram"],
    baseUnit: "Kilogram",
    conversions: {
      "Kilogram": 1,
      "Gram": 1000,
      "Pound": 2.20462,
      "Ounce": 35.274,
      "Ton": 0.001,
      "Stone": 0.157473,
      "Milligram": 1000000,
    },
  },
  data: {
    name: "Data",
    units: ["Byte", "Kilobyte", "Megabyte", "Gigabyte", "Terabyte", "Petabyte", "Bit", "Kilobit", "Megabit", "Gigabit"],
    baseUnit: "Byte",
    conversions: {
      "Byte": 1,
      "Kilobyte": 0.001,
      "Megabyte": 0.000001,
      "Gigabyte": 0.000000001,
      "Terabyte": 0.000000000001,
      "Petabyte": 0.000000000000001,
      "Bit": 8,
      "Kilobit": 0.008,
      "Megabit": 0.000008,
      "Gigabit": 0.000000008,
    },
  },
  speed: {
    name: "Speed",
    units: ["m/s", "km/h", "mph", "ft/s", "knot", "mach"],
    baseUnit: "m/s",
    conversions: {
      "m/s": 1,
      "km/h": 3.6,
      "mph": 2.23694,
      "ft/s": 3.28084,
      "knot": 1.94384,
      "mach": 0.00291545,
    },
  },
  time: {
    name: "Time",
    units: ["Second", "Minute", "Hour", "Day", "Week", "Month", "Year"],
    baseUnit: "Second",
    conversions: {
      "Second": 1,
      "Minute": 1/60,
      "Hour": 1/3600,
      "Day": 1/86400,
      "Week": 1/604800,
      "Month": 1/2629746,
      "Year": 1/31556952,
    },
  },
  pressure: {
    name: "Pressure",
    units: ["Pascal", "Bar", "PSI", "Atmosphere", "Torr", "mmHg"],
    baseUnit: "Pascal",
    conversions: {
      "Pascal": 1,
      "Bar": 0.00001,
      "PSI": 0.000145038,
      "Atmosphere": 0.00000986923,
      "Torr": 0.00750062,
      "mmHg": 0.00750062,
    },
  },
  force: {
    name: "Force",
    units: ["Newton", "Pound-force", "Kilogram-force", "Dyne"],
    baseUnit: "Newton",
    conversions: {
      "Newton": 1,
      "Pound-force": 0.224809,
      "Kilogram-force": 0.101972,
      "Dyne": 100000,
    },
  },
  power: {
    name: "Power",
    units: ["Watt", "Kilowatt", "Horsepower", "BTU/hour", "Calorie/second"],
    baseUnit: "Watt",
    conversions: {
      "Watt": 1,
      "Kilowatt": 0.001,
      "Horsepower": 0.00134102,
      "BTU/hour": 3.41214,
      "Calorie/second": 0.238846,
    },
  },
  energy: {
    name: "Energy",
    units: ["Joule", "Kilojoule", "Calorie", "Kilocalorie", "BTU", "kWh"],
    baseUnit: "Joule",
    conversions: {
      "Joule": 1,
      "Kilojoule": 0.001,
      "Calorie": 0.238846,
      "Kilocalorie": 0.000238846,
      "BTU": 0.000947817,
      "kWh": 2.77778e-7,
    },
  },
  frequency: {
    name: "Frequency",
    units: ["Hertz", "Kilohertz", "Megahertz", "Gigahertz"],
    baseUnit: "Hertz",
    conversions: {
      "Hertz": 1,
      "Kilohertz": 0.001,
      "Megahertz": 0.000001,
      "Gigahertz": 0.000000001,
    },
  },
  angle: {
    name: "Angle",
    units: ["Degree", "Radian", "Gradian"],
    baseUnit: "Degree",
    conversions: {
      "Degree": 1,
      "Radian": Math.PI / 180,
      "Gradian": 1.11111,
    },
  },
  fuel: {
    name: "Fuel Consumption",
    units: ["L/100km", "MPG (US)", "MPG (UK)", "km/L"],
    baseUnit: "L/100km",
    conversions: {}, // Special handling required
  },
  age: {
    name: "Age Calculator",
    units: ["Years", "Months", "Days", "Hours", "Minutes"],
    baseUnit: "Years",
    conversions: {
      "Years": 1,
      "Months": 12,
      "Days": 365.25,
      "Hours": 8766,
      "Minutes": 525960,
    },
  },
  numeral: {
    name: "Numeral System",
    units: ["Decimal", "Binary", "Octal", "Hexadecimal"],
    baseUnit: "Decimal",
    conversions: {}, // Special handling required
  },
  gst: {
    name: "GST Calculator",
    units: ["Inclusive", "Exclusive"],
    baseUnit: "Exclusive",
    conversions: {}, // Special handling required
  },
  splitbill: {
    name: "Split Bill",
    units: ["Equal Split", "Custom Split"],
    baseUnit: "Equal Split",
    conversions: {}, // Special handling required
  },
  date: {
    name: "Date Calculator",
    units: ["Add Days", "Subtract Days", "Difference"],
    baseUnit: "Days",
    conversions: {}, // Special handling required
  },
  bmi: {
    name: "BMI Calculator",
    units: ["Metric", "Imperial"],
    baseUnit: "Metric",
    conversions: {}, // Special handling required
  },
  discount: {
    name: "Discount Calculator",
    units: ["Percentage", "Amount"],
    baseUnit: "Percentage",
    conversions: {}, // Special handling required
  },
  loan: {
    name: "Loan Calculator",
    units: ["Monthly", "Annual"],
    baseUnit: "Monthly",
    conversions: {}, // Special handling required
  },
  fuelefficiency: {
    name: "Fuel Efficiency",
    units: ["L/100km", "MPG (US)", "MPG (UK)", "km/L"],
    baseUnit: "L/100km",
    conversions: {}, // Special handling required
  },
  fuelcost: {
    name: "Fuel Cost",
    units: ["Per Liter", "Per Gallon"],
    baseUnit: "Per Liter",
    conversions: {}, // Special handling required
  },
  investment: {
    name: "Investment Calculator",
    units: ["Simple Interest", "Compound Interest"],
    baseUnit: "Compound Interest",
    conversions: {}, // Special handling required
  },
  menstrualcycle: {
    name: "Menstrual Cycle",
    units: ["Days", "Weeks"],
    baseUnit: "Days",
    conversions: {
      "Days": 1,
      "Weeks": 1/7,
    },
  },
  bmr: {
    name: "BMR Calculator",
    units: ["Harris-Benedict", "Mifflin-St Jeor"],
    baseUnit: "Mifflin-St Jeor",
    conversions: {}, // Special handling required
  },
  gpa: {
    name: "GPA Calculator",
    units: ["4.0 Scale", "10.0 Scale"],
    baseUnit: "4.0 Scale",
    conversions: {}, // Special handling required
  },
  worldtime: {
    name: "World Time",
    units: ["UTC", "Local Time"],
    baseUnit: "UTC",
    conversions: {}, // Special handling required
  },
  savings: {
    name: "Savings Calculator",
    units: ["Monthly", "Annual"],
    baseUnit: "Monthly",
    conversions: {}, // Special handling required
  },
};

export function convertUnit(value: number, fromUnit: string, toUnit: string, category: UnitCategory): number {
  const categoryData = UNIT_CATEGORIES[category];
  
  if (!categoryData) {
    throw new Error(`Unknown category: ${category}`);
  }

  // Special handling for temperature
  if (category === "temperature") {
    return convertTemperature(value, fromUnit, toUnit);
  }

  // Special handling for fuel consumption
  if (category === "fuel" || category === "fuelefficiency") {
    return convertFuelConsumption(value, fromUnit, toUnit);
  }

  // For standard linear conversions
  const fromConversion = categoryData.conversions[fromUnit];
  const toConversion = categoryData.conversions[toUnit];

  if (fromConversion === undefined || toConversion === undefined) {
    throw new Error(`Conversion not supported between ${fromUnit} and ${toUnit}`);
  }

  // Convert to base unit first, then to target unit
  const baseValue = value / fromConversion;
  return baseValue * toConversion;
}

function convertTemperature(value: number, fromUnit: string, toUnit: string): number {
  // Convert from source to Celsius first
  let celsius: number;
  
  switch (fromUnit) {
    case "Celsius":
      celsius = value;
      break;
    case "Fahrenheit":
      celsius = (value - 32) * 5/9;
      break;
    case "Kelvin":
      celsius = value - 273.15;
      break;
    default:
      throw new Error(`Unknown temperature unit: ${fromUnit}`);
  }

  // Convert from Celsius to target unit
  switch (toUnit) {
    case "Celsius":
      return celsius;
    case "Fahrenheit":
      return celsius * 9/5 + 32;
    case "Kelvin":
      return celsius + 273.15;
    default:
      throw new Error(`Unknown temperature unit: ${toUnit}`);
  }
}

function convertFuelConsumption(value: number, fromUnit: string, toUnit: string): number {
  // Convert to L/100km first
  let l100km: number;

  switch (fromUnit) {
    case "L/100km":
      l100km = value;
      break;
    case "MPG (US)":
      l100km = 235.214 / value;
      break;
    case "MPG (UK)":
      l100km = 282.481 / value;
      break;
    case "km/L":
      l100km = 100 / value;
      break;
    default:
      throw new Error(`Unknown fuel consumption unit: ${fromUnit}`);
  }

  // Convert from L/100km to target unit
  switch (toUnit) {
    case "L/100km":
      return l100km;
    case "MPG (US)":
      return 235.214 / l100km;
    case "MPG (UK)":
      return 282.481 / l100km;
    case "km/L":
      return 100 / l100km;
    default:
      throw new Error(`Unknown fuel consumption unit: ${toUnit}`);
  }
}
