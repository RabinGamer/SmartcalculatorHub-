import { useState, useCallback } from "react";
import { evaluateExpression, isOperator } from "@/lib/calculator-utils";

export interface CalculatorState {
  display: string;
  expression: string;
  previousOperand: string;
  operation: string | null;
  waitingForOperand: boolean;
  history: string[];
  memory: number;
  showHistory: boolean;
}

export function useCalculator() {
  const [state, setState] = useState<CalculatorState>({
    display: "0",
    expression: "",
    previousOperand: "",
    operation: null,
    waitingForOperand: false,
    history: [],
    memory: 0,
    showHistory: false,
  });

  const clear = useCallback(() => {
    setState(prev => ({
      ...prev,
      display: "0",
      expression: "",
      previousOperand: "",
      operation: null,
      waitingForOperand: false,
    }));
  }, []);

  const inputNumber = useCallback((num: string) => {
    setState((prev) => {
      if (prev.waitingForOperand) {
        const newExpression = prev.expression.includes("=") ? num : prev.expression + num;
        return {
          ...prev,
          display: num,
          expression: newExpression,
          waitingForOperand: false,
        };
      }

      const newDisplay = prev.display === "0" ? num : prev.display + num;
      return {
        ...prev,
        display: newDisplay,
        expression: prev.expression === "" || prev.expression.includes("=") ? newDisplay : prev.expression.replace(/[0-9.]+$/, newDisplay),
      };
    });
  }, []);

  const inputDecimal = useCallback(() => {
    setState((prev) => {
      if (prev.waitingForOperand) {
        const newExpression = prev.expression.includes("=") ? "0." : prev.expression + "0.";
        return {
          ...prev,
          display: "0.",
          expression: newExpression,
          waitingForOperand: false,
        };
      }

      if (prev.display.indexOf(".") === -1) {
        const newDisplay = prev.display + ".";
        return {
          ...prev,
          display: newDisplay,
          expression: prev.expression === "" || prev.expression.includes("=") ? newDisplay : prev.expression.replace(/[0-9.]+$/, newDisplay),
        };
      }

      return prev;
    });
  }, []);

  const inputOperation = useCallback((nextOperation: string) => {
    setState((prev) => {
      const inputValue = parseFloat(prev.display);

      if (prev.previousOperand === "") {
        return {
          ...prev,
          previousOperand: prev.display,
          operation: nextOperation,
          expression: `${prev.display} ${nextOperation} `,
          waitingForOperand: true,
        };
      }

      if (prev.operation && prev.waitingForOperand) {
        return {
          ...prev,
          operation: nextOperation,
          expression: prev.expression.replace(/[+\-×÷] $/, `${nextOperation} `),
        };
      }

      const prevValue = parseFloat(prev.previousOperand);
      let result: number;

      try {
        result = evaluateExpression(prevValue, inputValue, prev.operation!);
      } catch (error) {
        return {
          ...prev,
          display: "Error",
          expression: "Error",
          previousOperand: "",
          operation: null,
          waitingForOperand: true,
        };
      }

      return {
        ...prev,
        display: String(result),
        expression: `${result} ${nextOperation} `,
        previousOperand: String(result),
        operation: nextOperation,
        waitingForOperand: true,
      };
    });
  }, []);

  const calculate = useCallback(() => {
    setState((prev) => {
      const inputValue = parseFloat(prev.display);
      const prevValue = parseFloat(prev.previousOperand);

      if (prev.previousOperand === "" || prev.operation === null) {
        return prev;
      }

      let result: number;

      try {
        result = evaluateExpression(prevValue, inputValue, prev.operation);
      } catch (error) {
        return {
          ...prev,
          display: "Error",
          expression: "Error",
          previousOperand: "",
          operation: null,
          waitingForOperand: true,
        };
      }

      const calculation = `${prev.previousOperand} ${prev.operation} ${prev.display} = ${result}`;
      const resultExpression = `${prev.previousOperand} ${prev.operation} ${prev.display} = ${result}`;

      return {
        ...prev,
        display: String(result),
        expression: resultExpression,
        previousOperand: "",
        operation: null,
        waitingForOperand: true,
        history: [...prev.history, calculation].slice(-10), // Keep last 10 calculations
      };
    });
  }, []);

  const inputPercent = useCallback(() => {
    setState((prev) => {
      const value = parseFloat(prev.display);
      const result = value / 100;

      return {
        ...prev,
        display: String(result),
      };
    });
  }, []);

  const inputDoubleZero = useCallback(() => {
    setState((prev) => {
      if (prev.waitingForOperand) {
        return {
          ...prev,
          display: "00",
          waitingForOperand: false,
        };
      }

      return {
        ...prev,
        display: prev.display === "0" ? "00" : prev.display + "00",
      };
    });
  }, []);

  const handleInput = useCallback((input: string) => {
    if (input >= "0" && input <= "9") {
      inputNumber(input);
    } else if (input === ".") {
      inputDecimal();
    } else if (isOperator(input)) {
      inputOperation(input);
    } else if (input === "=") {
      calculate();
    } else if (input === "C" || input === "Escape") {
      clear();
    } else if (input === "%") {
      inputPercent();
    } else if (input === "00") {
      inputDoubleZero();
    }
  }, [inputNumber, inputDecimal, inputOperation, calculate, clear, inputPercent, inputDoubleZero]);

  // Memory functions
  const memoryStore = useCallback(() => {
    setState(prev => ({ ...prev, memory: parseFloat(prev.display) }));
  }, []);

  const memoryRecall = useCallback(() => {
    setState(prev => ({ 
      ...prev, 
      display: String(prev.memory),
      expression: prev.expression.includes("=") ? String(prev.memory) : prev.expression.replace(/[0-9.]+$/, String(prev.memory)),
      waitingForOperand: false 
    }));
  }, []);

  const memoryAdd = useCallback(() => {
    setState(prev => ({ ...prev, memory: prev.memory + parseFloat(prev.display) }));
  }, []);

  const memorySubtract = useCallback(() => {
    setState(prev => ({ ...prev, memory: prev.memory - parseFloat(prev.display) }));
  }, []);

  const memoryClear = useCallback(() => {
    setState(prev => ({ ...prev, memory: 0 }));
  }, []);

  // History functions
  const toggleHistory = useCallback(() => {
    setState(prev => ({ ...prev, showHistory: !prev.showHistory }));
  }, []);

  const clearHistory = useCallback(() => {
    setState(prev => ({ ...prev, history: [] }));
  }, []);

  const deleteHistoryItem = useCallback((index: number) => {
    setState(prev => ({ 
      ...prev, 
      history: prev.history.filter((_, i) => i !== index) 
    }));
  }, []);

  const recallFromHistory = useCallback((calculation: string) => {
    const result = calculation.split(' = ')[1];
    if (result) {
      setState(prev => ({ 
        ...prev, 
        display: result,
        expression: result,
        waitingForOperand: false 
      }));
    }
  }, []);

  return {
    ...state,
    clear,
    inputNumber,
    inputDecimal,
    inputOperation,
    calculate,
    inputPercent,
    inputDoubleZero,
    handleInput,
    memoryStore,
    memoryRecall,
    memoryAdd,
    memorySubtract,
    memoryClear,
    toggleHistory,
    clearHistory,
    deleteHistoryItem,
    recallFromHistory,
  };
}
