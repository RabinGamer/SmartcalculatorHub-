import { useState, useCallback, useEffect } from "react";
import { convertUnit, UNIT_CATEGORIES, UnitCategory } from "@/lib/unit-conversion";
import { getCurrencyRates } from "@/lib/currency-api";
import { useToast } from "@/hooks/use-toast";

export interface UnitConverterState {
  category: UnitCategory;
  fromUnit: string;
  toUnit: string;
  fromValue: string;
  toValue: string;
  isLoading: boolean;
  lastUpdated: Date | null;
  exchangeRate: number | null;
}

export function useUnitConverter() {
  const { toast } = useToast();
  const [state, setState] = useState<UnitConverterState>({
    category: "currency",
    fromUnit: "USD",
    toUnit: "EUR",
    fromValue: "",
    toValue: "",
    isLoading: false,
    lastUpdated: null,
    exchangeRate: null,
  });

  const setCategory = useCallback((category: UnitCategory) => {
    const units = UNIT_CATEGORIES[category].units;
    setState((prev) => ({
      ...prev,
      category,
      fromUnit: units[0],
      toUnit: units[1] || units[0],
      fromValue: "",
      toValue: "",
      lastUpdated: null,
      exchangeRate: null,
    }));
  }, []);

  const setFromUnit = useCallback((unit: string) => {
    setState((prev) => ({ ...prev, fromUnit: unit }));
  }, []);

  const setToUnit = useCallback((unit: string) => {
    setState((prev) => ({ ...prev, toUnit: unit }));
  }, []);

  const setFromValue = useCallback((value: string) => {
    setState((prev) => ({ ...prev, fromValue: value }));
  }, []);

  const convert = useCallback(async () => {
    if (!state.fromValue || isNaN(parseFloat(state.fromValue))) {
      setState((prev) => ({ ...prev, toValue: "" }));
      return;
    }

    const fromValue = parseFloat(state.fromValue);
    
    try {
      setState((prev) => ({ ...prev, isLoading: true }));

      let result: number;
      let exchangeRate: number | null = null;

      if (state.category === "currency") {
        // Get real-time exchange rates for currency conversion
        const rates = await getCurrencyRates(state.fromUnit);
        const rate = rates[state.toUnit];
        
        if (!rate) {
          throw new Error(`Exchange rate not found for ${state.fromUnit} to ${state.toUnit}`);
        }

        result = fromValue * rate;
        exchangeRate = rate;
      } else {
        // Use static conversion for other units
        result = convertUnit(fromValue, state.fromUnit, state.toUnit, state.category);
      }

      setState((prev) => ({
        ...prev,
        toValue: result.toFixed(6).replace(/\.?0+$/, ""),
        isLoading: false,
        lastUpdated: new Date(),
        exchangeRate,
      }));
    } catch (error) {
      console.error("Conversion error:", error);
      toast({
        title: "Conversion Error",
        description: error instanceof Error ? error.message : "Failed to convert units",
        variant: "destructive",
      });
      
      setState((prev) => ({
        ...prev,
        toValue: "",
        isLoading: false,
        exchangeRate: null,
      }));
    }
  }, [state.fromValue, state.fromUnit, state.toUnit, state.category, toast]);

  // Auto-convert when inputs change
  useEffect(() => {
    const timer = setTimeout(() => {
      convert();
    }, 300); // Debounce conversion

    return () => clearTimeout(timer);
  }, [convert]);

  return {
    ...state,
    setCategory,
    setFromUnit,
    setToUnit,
    setFromValue,
    convert,
    availableUnits: UNIT_CATEGORIES[state.category].units,
    categoryName: UNIT_CATEGORIES[state.category].name,
  };
}
