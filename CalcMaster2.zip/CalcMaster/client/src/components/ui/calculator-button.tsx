import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes, forwardRef } from "react";

interface CalculatorButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "number" | "operator" | "function" | "special";
  children: React.ReactNode;
}

const CalculatorButton = forwardRef<HTMLButtonElement, CalculatorButtonProps>(
  ({ className, variant = "number", children, ...props }, ref) => {
    const variantClasses = {
      number: "number-btn",
      operator: "operator-btn", 
      function: "function-btn",
      special: "special-btn",
    };

    return (
      <button
        className={cn(variantClasses[variant], className)}
        ref={ref}
        {...props}
      >
        {children}
      </button>
    );
  }
);

CalculatorButton.displayName = "CalculatorButton";

export { CalculatorButton };
