import { useEffect } from "react";
import { CalculatorButton } from "@/components/ui/calculator-button";
import { useCalculator } from "@/hooks/use-calculator";

export default function BasicCalculator() {
  const calculator = useCalculator();

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      event.preventDefault();
      
      const key = event.key;
      
      if (key >= "0" && key <= "9") {
        calculator.inputNumber(key);
      } else if (key === ".") {
        calculator.inputDecimal();
      } else if (key === "+" || key === "-") {
        calculator.inputOperation(key);
      } else if (key === "*") {
        calculator.inputOperation("×");
      } else if (key === "/") {
        calculator.inputOperation("÷");
      } else if (key === "Enter" || key === "=") {
        calculator.calculate();
      } else if (key === "Escape" || key === "c" || key === "C") {
        calculator.clear();
      } else if (key === "%") {
        calculator.inputPercent();
      } else if (key === "Backspace") {
        // Handle backspace if needed
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [calculator]);

  return (
    <div className="bg-card rounded-xl p-6 border border-border">
      <div className="mb-6">
        {calculator.expression && calculator.expression !== calculator.display && (
          <div className="text-right text-sm text-muted-foreground p-2 min-h-[30px]" data-testid="basic-expression">
            {calculator.expression}
          </div>
        )}
        <div className="display" data-testid="basic-display">
          {calculator.display}
        </div>
        
        {/* Memory indicator */}
        {calculator.memory !== 0 && (
          <div className="text-right text-xs text-accent mt-1">
            M: {calculator.memory}
          </div>
        )}
      </div>

      {/* History Panel */}
      {calculator.showHistory && (
        <div className="mb-4 bg-muted rounded-lg p-4 max-h-40 overflow-y-auto">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium">History</h3>
            <button 
              onClick={calculator.clearHistory}
              className="text-xs text-muted-foreground hover:text-foreground"
              data-testid="clear-history"
            >
              Clear All
            </button>
          </div>
          {calculator.history.length === 0 ? (
            <p className="text-xs text-muted-foreground">No calculations yet</p>
          ) : (
            <div className="space-y-1">
              {calculator.history.slice().reverse().map((calc, index) => (
                <div 
                  key={index} 
                  className="flex justify-between items-center text-xs hover:bg-background rounded p-2 cursor-pointer"
                  onClick={() => calculator.recallFromHistory(calc)}
                  data-testid={`history-item-${index}`}
                >
                  <span>{calc}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      calculator.deleteHistoryItem(calculator.history.length - 1 - index);
                    }}
                    className="text-muted-foreground hover:text-destructive ml-2"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Memory and History Controls */}
      <div className="grid grid-cols-6 gap-2 mb-4">
        <CalculatorButton
          variant="special"
          className="text-sm h-10"
          onClick={calculator.memoryClear}
          data-testid="button-mc"
        >
          MC
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="text-sm h-10"
          onClick={calculator.memoryRecall}
          data-testid="button-mr"
        >
          MR
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="text-sm h-10"
          onClick={calculator.memoryStore}
          data-testid="button-ms"
        >
          MS
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="text-sm h-10"
          onClick={calculator.memoryAdd}
          data-testid="button-m-plus"
        >
          M+
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="text-sm h-10"
          onClick={calculator.memorySubtract}
          data-testid="button-m-minus"
        >
          M-
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="text-sm h-10"
          onClick={calculator.toggleHistory}
          data-testid="button-history"
        >
          {calculator.showHistory ? "H▲" : "H▼"}
        </CalculatorButton>
      </div>
      
      <div className="grid grid-cols-4 gap-3">
        {/* Row 1 */}
        <CalculatorButton
          variant="function"
          onClick={calculator.clear}
          data-testid="button-clear"
        >
          C
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          onClick={() => {/* TODO: Implement parentheses */}}
          data-testid="button-parentheses"
        >
          ()
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          onClick={calculator.inputPercent}
          data-testid="button-percent"
        >
          %
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          onClick={() => calculator.inputOperation("÷")}
          data-testid="button-divide"
        >
          ÷
        </CalculatorButton>
        
        {/* Row 2 */}
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("7")}
          data-testid="button-7"
        >
          7
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("8")}
          data-testid="button-8"
        >
          8
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("9")}
          data-testid="button-9"
        >
          9
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          onClick={() => calculator.inputOperation("×")}
          data-testid="button-multiply"
        >
          ×
        </CalculatorButton>
        
        {/* Row 3 */}
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("4")}
          data-testid="button-4"
        >
          4
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("5")}
          data-testid="button-5"
        >
          5
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("6")}
          data-testid="button-6"
        >
          6
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          onClick={() => calculator.inputOperation("-")}
          data-testid="button-subtract"
        >
          -
        </CalculatorButton>
        
        {/* Row 4 */}
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("1")}
          data-testid="button-1"
        >
          1
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("2")}
          data-testid="button-2"
        >
          2
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("3")}
          data-testid="button-3"
        >
          3
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          onClick={() => calculator.inputOperation("+")}
          data-testid="button-add"
        >
          +
        </CalculatorButton>
        
        {/* Row 5 */}
        <CalculatorButton
          variant="number"
          onClick={() => calculator.inputNumber("0")}
          data-testid="button-0"
        >
          0
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={calculator.inputDoubleZero}
          data-testid="button-double-zero"
        >
          00
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          onClick={calculator.inputDecimal}
          data-testid="button-decimal"
        >
          .
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          onClick={calculator.calculate}
          data-testid="button-equals"
        >
          =
        </CalculatorButton>
      </div>
    </div>
  );
}
