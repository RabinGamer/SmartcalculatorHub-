import { useState, useEffect } from "react";
import { CalculatorButton } from "@/components/ui/calculator-button";
import { evaluateScientificFunction, CONSTANTS } from "@/lib/calculator-utils";
import { useCalculator } from "@/hooks/use-calculator";

export default function ScientificCalculator() {
  const calculator = useCalculator();
  const [angleMode, setAngleMode] = useState<"rad" | "deg">("rad");
  const [isInverse, setIsInverse] = useState(false);

  const handleScientificOperation = (operation: string) => {
    try {
      const currentValue = parseFloat(calculator.display);
      let result: number;

      switch (operation) {
        case "sin":
        case "cos": 
        case "tan":
        case "asin":
        case "acos":
        case "atan":
        case "log":
        case "ln":
        case "sqrt":
        case "exp":
        case "abs":
        case "inverse":
        case "square":
          result = evaluateScientificFunction(
            isInverse && ["sin", "cos", "tan"].includes(operation) 
              ? `a${operation}` 
              : operation, 
            currentValue, 
            angleMode
          );
          break;
        case "pi":
          result = CONSTANTS.pi;
          break;
        case "e":
          result = CONSTANTS.e;
          break;
        case "power":
          // This would require a second operand, implement as needed
          calculator.inputOperation("^");
          return;
        default:
          throw new Error(`Unknown operation: ${operation}`);
      }

      // Update display with result
      calculator.inputNumber(result.toString());
    } catch (error) {
      console.error("Scientific calculation error:", error);
      calculator.clear();
      calculator.inputNumber("Error");
    }
  };

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      
      if (key >= "0" && key <= "9") {
        calculator.inputNumber(key);
      } else if (key === ".") {
        calculator.inputDecimal();
      } else if (key === "+" || key === "-") {
        calculator.inputOperation(key);
      } else if (key === "*") {
        calculator.inputOperation("×");
      } else if (key === "/") {
        calculator.inputOperation("÷");
      } else if (key === "Enter" || key === "=") {
        calculator.calculate();
      } else if (key === "Escape" || key === "c") {
        calculator.clear();
      } else if (key === "%") {
        calculator.inputPercent();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [calculator]);

  return (
    <div className="bg-card rounded-xl p-4 sm:p-6 border border-border">
      <div className="mb-4">
        {calculator.expression && calculator.expression !== calculator.display && (
          <div className="text-right text-sm text-muted-foreground p-2 min-h-[30px]" data-testid="scientific-expression">
            {calculator.expression}
          </div>
        )}
        <div className="display" data-testid="scientific-display">
          {calculator.display}
        </div>
        <div className="flex justify-between items-center mt-2 text-sm text-muted-foreground">
          <span>Mode: {angleMode.toUpperCase()}</span>
          <div className="flex items-center space-x-2">
            {calculator.memory !== 0 && <span className="text-accent">M: {calculator.memory}</span>}
            {isInverse && <span className="text-accent">INV</span>}
          </div>
        </div>
      </div>

      {/* History Panel */}
      {calculator.showHistory && (
        <div className="mb-4 bg-muted rounded-lg p-4 max-h-32 overflow-y-auto">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium">History</h3>
            <button 
              onClick={calculator.clearHistory}
              className="text-xs text-muted-foreground hover:text-foreground"
              data-testid="clear-history-scientific"
            >
              Clear All
            </button>
          </div>
          {calculator.history.length === 0 ? (
            <p className="text-xs text-muted-foreground">No calculations yet</p>
          ) : (
            <div className="space-y-1">
              {calculator.history.slice().reverse().map((calc, index) => (
                <div 
                  key={index} 
                  className="flex justify-between items-center text-xs hover:bg-background rounded p-2 cursor-pointer"
                  onClick={() => calculator.recallFromHistory(calc)}
                  data-testid={`history-item-scientific-${index}`}
                >
                  <span>{calc}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      calculator.deleteHistoryItem(calculator.history.length - 1 - index);
                    }}
                    className="text-muted-foreground hover:text-destructive ml-2"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Memory and History Controls */}
      <div className="grid grid-cols-6 gap-1 mb-3 text-xs">
        <CalculatorButton
          variant="special"
          className="h-8 text-xs"
          onClick={calculator.memoryClear}
          data-testid="button-mc-scientific"
        >
          MC
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-8 text-xs"
          onClick={calculator.memoryRecall}
          data-testid="button-mr-scientific"
        >
          MR
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-8 text-xs"
          onClick={calculator.memoryStore}
          data-testid="button-ms-scientific"
        >
          MS
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-8 text-xs"
          onClick={calculator.memoryAdd}
          data-testid="button-m-plus-scientific"
        >
          M+
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-8 text-xs"
          onClick={calculator.memorySubtract}
          data-testid="button-m-minus-scientific"
        >
          M-
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-8 text-xs"
          onClick={calculator.toggleHistory}
          data-testid="button-history-scientific"
        >
          {calculator.showHistory ? "H▲" : "H▼"}
        </CalculatorButton>
      </div>
      
      <div className="grid grid-cols-5 gap-2 text-sm">
        {/* Row 1 - Functions */}
        <CalculatorButton
          variant="special"
          className="h-12"
          onClick={() => setIsInverse(!isInverse)}
          data-testid="button-inverse-toggle"
        >
          ↹
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-12"
          onClick={() => setAngleMode(angleMode === "rad" ? "deg" : "rad")}
          data-testid="button-angle-mode"
        >
          {angleMode.toUpperCase()}
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("sin")}
          data-testid="button-sin"
        >
          {isInverse ? "asin" : "sin"}
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("cos")}
          data-testid="button-cos"
        >
          {isInverse ? "acos" : "cos"}
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("tan")}
          data-testid="button-tan"
        >
          {isInverse ? "atan" : "tan"}
        </CalculatorButton>
        
        {/* Row 2 - Advanced Functions */}
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("sqrt")}
          data-testid="button-sqrt"
        >
          √
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("cbrt")}
          data-testid="button-cbrt"
        >
          ∛
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("ln")}
          data-testid="button-ln"
        >
          ln
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("log")}
          data-testid="button-log"
        >
          log
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("log2")}
          data-testid="button-log2"
        >
          log₂
        </CalculatorButton>
        
        {/* Row 3 - Hyperbolic Functions */}
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("sinh")}
          data-testid="button-sinh"
        >
          sinh
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("cosh")}
          data-testid="button-cosh"
        >
          cosh
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("tanh")}
          data-testid="button-tanh"
        >
          tanh
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("exp")}
          data-testid="button-exp"
        >
          e^x
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("exp10")}
          data-testid="button-exp10"
        >
          10^x
        </CalculatorButton>
        
        {/* Row 4 - Powers and Operations */}
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("square")}
          data-testid="button-square"
        >
          x²
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("cube")}
          data-testid="button-cube"
        >
          x³
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("inverse")}
          data-testid="button-reciprocal"
        >
          1/x
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("factorial")}
          data-testid="button-factorial"
        >
          n!
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("abs")}
          data-testid="button-abs"
        >
          |x|
        </CalculatorButton>
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={calculator.clear}
          data-testid="button-clear-scientific"
        >
          C
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-12"
          onClick={() => {/* TODO: Implement parentheses */}}
          data-testid="button-parentheses-scientific"
        >
          ()
        </CalculatorButton>
        <CalculatorButton
          variant="special"
          className="h-12"
          onClick={calculator.inputPercent}
          data-testid="button-percent-scientific"
        >
          %
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          className="h-12"
          onClick={() => calculator.inputOperation("÷")}
          data-testid="button-divide-scientific"
        >
          ÷
        </CalculatorButton>
        
        {/* Row 5 - Numbers and Operations */}
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("power")}
          data-testid="button-power"
        >
          x^y
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("7")}
          data-testid="button-7-scientific"
        >
          7
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("8")}
          data-testid="button-8-scientific"
        >
          8
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("9")}
          data-testid="button-9-scientific"
        >
          9
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          className="h-12"
          onClick={() => calculator.inputOperation("×")}
          data-testid="button-multiply-scientific"
        >
          ×
        </CalculatorButton>
        
        {/* Row 5 */}
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("abs")}
          data-testid="button-abs"
        >
          |x|
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("4")}
          data-testid="button-4-scientific"
        >
          4
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("5")}
          data-testid="button-5-scientific"
        >
          5
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("6")}
          data-testid="button-6-scientific"
        >
          6
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          className="h-12"
          onClick={() => calculator.inputOperation("-")}
          data-testid="button-subtract-scientific"
        >
          -
        </CalculatorButton>
        
        {/* Row 6 */}
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("pi")}
          data-testid="button-pi"
        >
          π
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("1")}
          data-testid="button-1-scientific"
        >
          1
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("2")}
          data-testid="button-2-scientific"
        >
          2
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("3")}
          data-testid="button-3-scientific"
        >
          3
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          className="h-12"
          onClick={() => calculator.inputOperation("+")}
          data-testid="button-add-scientific"
        >
          +
        </CalculatorButton>
        
        {/* Row 7 */}
        <CalculatorButton
          variant="function"
          className="h-12"
          onClick={() => handleScientificOperation("e")}
          data-testid="button-e"
        >
          e
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={() => calculator.inputNumber("0")}
          data-testid="button-0-scientific"
        >
          0
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={calculator.inputDoubleZero}
          data-testid="button-double-zero-scientific"
        >
          00
        </CalculatorButton>
        <CalculatorButton
          variant="number"
          className="h-12"
          onClick={calculator.inputDecimal}
          data-testid="button-decimal-scientific"
        >
          .
        </CalculatorButton>
        <CalculatorButton
          variant="operator"
          className="h-12"
          onClick={calculator.calculate}
          data-testid="button-equals-scientific"
        >
          =
        </CalculatorButton>
      </div>
    </div>
  );
}
