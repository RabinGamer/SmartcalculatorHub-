import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useToast } from "@/hooks/use-toast";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

interface GraphFunction {
  id: string;
  expression: string;
  color: string;
  visible: boolean;
}

export function GraphingCalculator() {
  const [functions, setFunctions] = useState<GraphFunction[]>([
    { id: '1', expression: 'x^2', color: '#3b82f6', visible: true },
    { id: '2', expression: 'sin(x)', color: '#ef4444', visible: false },
    { id: '3', expression: 'cos(x)', color: '#22c55e', visible: false },
  ]);
  const [newFunction, setNewFunction] = useState('');
  const [xMin, setXMin] = useState(-10);
  const [xMax, setXMax] = useState(10);
  const [yMin, setYMin] = useState(-10);
  const [yMax, setYMax] = useState(10);
  const [resolution, setResolution] = useState(1000);
  const { toast } = useToast();

  // Function to evaluate mathematical expressions
  const evaluateExpression = (expression: string, x: number): number => {
    try {
      // Replace mathematical functions and constants
      let expr = expression
        .replace(/\bx\b/g, x.toString())
        .replace(/sin\(/g, 'Math.sin(')
        .replace(/cos\(/g, 'Math.cos(')
        .replace(/tan\(/g, 'Math.tan(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/ln\(/g, 'Math.log(')
        .replace(/sqrt\(/g, 'Math.sqrt(')
        .replace(/abs\(/g, 'Math.abs(')
        .replace(/exp\(/g, 'Math.exp(')
        .replace(/\^/g, '**')
        .replace(/pi/g, Math.PI.toString())
        .replace(/e(?![0-9])/g, Math.E.toString());

      // eslint-disable-next-line no-eval
      return eval(expr);
    } catch (error) {
      return NaN;
    }
  };

  // Generate data points for a function
  const generateDataPoints = (func: GraphFunction) => {
    const points: { x: number; y: number }[] = [];
    const step = (xMax - xMin) / resolution;

    for (let x = xMin; x <= xMax; x += step) {
      const y = evaluateExpression(func.expression, x);
      if (!isNaN(y) && isFinite(y)) {
        points.push({ x, y });
      }
    }
    return points;
  };

  // Prepare chart data
  const chartData = {
    datasets: functions
      .filter(func => func.visible)
      .map(func => ({
        label: func.expression,
        data: generateDataPoints(func),
        borderColor: func.color,
        backgroundColor: func.color + '20',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 4,
        tension: 0.1,
      })),
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: 'rgb(156, 163, 175)',
        },
      },
      title: {
        display: true,
        text: 'Function Graph',
        color: 'rgb(156, 163, 175)',
      },
    },
    scales: {
      x: {
        type: 'linear' as const,
        position: 'bottom' as const,
        min: xMin,
        max: xMax,
        grid: {
          color: 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: 'rgb(156, 163, 175)',
        },
      },
      y: {
        min: yMin,
        max: yMax,
        grid: {
          color: 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: 'rgb(156, 163, 175)',
        },
      },
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
  };

  const addFunction = () => {
    if (!newFunction.trim()) return;

    const colors = ['#3b82f6', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6', '#06b6d4'];
    const newId = Date.now().toString();
    const color = colors[functions.length % colors.length];

    setFunctions(prev => [
      ...prev,
      { id: newId, expression: newFunction, color, visible: true }
    ]);
    setNewFunction('');
    toast({
      title: "Function Added",
      description: `Added function: ${newFunction}`,
    });
  };

  const removeFunction = (id: string) => {
    setFunctions(prev => prev.filter(func => func.id !== id));
  };

  const toggleFunction = (id: string) => {
    setFunctions(prev => prev.map(func => 
      func.id === id ? { ...func, visible: !func.visible } : func
    ));
  };

  const resetView = () => {
    setXMin(-10);
    setXMax(10);
    setYMin(-10);
    setYMax(10);
  };

  return (
    <div className="bg-card rounded-xl p-6 border border-border space-y-6">
      {/* Graph Display */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Function Graph</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96" data-testid="graph-display">
            <Line data={chartData} options={chartOptions} />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Function Controls */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Functions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Add New Function */}
            <div className="flex gap-2">
              <Input
                placeholder="Enter function (e.g., x^2, sin(x), log(x))"
                value={newFunction}
                onChange={(e) => setNewFunction(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addFunction()}
                data-testid="input-function"
              />
              <Button onClick={addFunction} data-testid="button-add-function">
                Add
              </Button>
            </div>

            <Separator />

            {/* Function List */}
            <div className="space-y-2">
              {functions.map((func) => (
                <div key={func.id} className="flex items-center gap-3 p-2 rounded border">
                  <div
                    className="w-4 h-4 rounded"
                    style={{ backgroundColor: func.color }}
                  />
                  <span className="flex-1 font-mono text-sm">{func.expression}</span>
                  <Button
                    variant={func.visible ? "default" : "outline"}
                    size="sm"
                    onClick={() => toggleFunction(func.id)}
                    data-testid={`button-toggle-${func.id}`}
                  >
                    {func.visible ? "Hide" : "Show"}
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => removeFunction(func.id)}
                    data-testid={`button-remove-${func.id}`}
                  >
                    ×
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* View Controls */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">View Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* X-axis Range */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="x-min">X Min</Label>
                <Input
                  id="x-min"
                  type="number"
                  value={xMin}
                  onChange={(e) => setXMin(Number(e.target.value))}
                  data-testid="input-x-min"
                />
              </div>
              <div>
                <Label htmlFor="x-max">X Max</Label>
                <Input
                  id="x-max"
                  type="number"
                  value={xMax}
                  onChange={(e) => setXMax(Number(e.target.value))}
                  data-testid="input-x-max"
                />
              </div>
            </div>

            {/* Y-axis Range */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="y-min">Y Min</Label>
                <Input
                  id="y-min"
                  type="number"
                  value={yMin}
                  onChange={(e) => setYMin(Number(e.target.value))}
                  data-testid="input-y-min"
                />
              </div>
              <div>
                <Label htmlFor="y-max">Y Max</Label>
                <Input
                  id="y-max"
                  type="number"
                  value={yMax}
                  onChange={(e) => setYMax(Number(e.target.value))}
                  data-testid="input-y-max"
                />
              </div>
            </div>

            {/* Resolution */}
            <div>
              <Label htmlFor="resolution">Resolution (points)</Label>
              <Input
                id="resolution"
                type="number"
                min="100"
                max="2000"
                value={resolution}
                onChange={(e) => setResolution(Number(e.target.value))}
                data-testid="input-resolution"
              />
            </div>

            <Button onClick={resetView} className="w-full" data-testid="button-reset-view">
              Reset View
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Function Examples */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Function Examples</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <div className="p-2 bg-muted rounded">
              <strong>Polynomial:</strong><br />
              x^2, x^3, 2*x+1
            </div>
            <div className="p-2 bg-muted rounded">
              <strong>Trigonometric:</strong><br />
              sin(x), cos(x), tan(x)
            </div>
            <div className="p-2 bg-muted rounded">
              <strong>Exponential:</strong><br />
              exp(x), log(x), ln(x)
            </div>
            <div className="p-2 bg-muted rounded">
              <strong>Complex:</strong><br />
              sin(x)*cos(x), x^2+sin(x)
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}