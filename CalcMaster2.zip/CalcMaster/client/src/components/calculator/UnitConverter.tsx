import { useUnitConverter } from "@/hooks/use-unit-converter";
import { UNIT_CATEGORIES, UnitCategory } from "@/lib/unit-conversion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function UnitConverter() {
  const converter = useUnitConverter();

  const handleCategoryChange = (value: string) => {
    converter.setCategory(value as UnitCategory);
  };

  const handleFromUnitChange = (value: string) => {
    converter.setFromUnit(value);
  };

  const handleToUnitChange = (value: string) => {
    converter.setToUnit(value);
  };

  const handleFromValueChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    converter.setFromValue(event.target.value);
  };

  const getCategoryIcon = (category: UnitCategory): string => {
    const iconMap: Record<UnitCategory, string> = {
      currency: "💱",
      area: "📐",
      length: "📏",
      temperature: "🌡️",
      volume: "🪣",
      mass: "⚖️",
      data: "💾",
      speed: "🚗",
      time: "⏰",
      pressure: "🔩",
      force: "💪",
      power: "⚡",
      energy: "🔋",
      frequency: "📡",
      angle: "📐",
      fuel: "⛽",
      age: "🎂",
      numeral: "🔢",
      gst: "💰",
      splitbill: "🧾",
      date: "📅",
      bmi: "💪",
      discount: "🏷️",
      loan: "🏦",
      fuelefficiency: "⛽",
      fuelcost: "💸",
      investment: "📈",
      menstrualcycle: "🩸",
      bmr: "🔥",
      gpa: "🎓",
      worldtime: "🌍",
      savings: "💰",
    };
    return iconMap[category];
  };

  return (
    <div className="bg-card rounded-xl p-6 border border-border">
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-4 text-foreground">Unit Converter</h2>
        
        {/* Category Selection */}
        <div className="mb-6">
          <Label htmlFor="category-select" className="block text-sm font-medium mb-2">
            Category
          </Label>
          <Select value={converter.category} onValueChange={handleCategoryChange}>
            <SelectTrigger 
              id="category-select"
              className="w-full bg-secondary text-secondary-foreground border border-border"
              data-testid="select-category"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border">
              {Object.entries(UNIT_CATEGORIES).map(([key, data]) => (
                <SelectItem 
                  key={key} 
                  value={key}
                  className="hover:bg-accent"
                  data-testid={`category-${key}`}
                >
                  {getCategoryIcon(key as UnitCategory)} {data.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Conversion Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* From Unit */}
          <div className="space-y-4">
            <Label className="block text-sm font-medium">From</Label>
            <Select value={converter.fromUnit} onValueChange={handleFromUnitChange}>
              <SelectTrigger 
                className="w-full bg-secondary text-secondary-foreground border border-border"
                data-testid="select-from-unit"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border">
                {converter.availableUnits.map((unit) => (
                  <SelectItem 
                    key={unit} 
                    value={unit}
                    className="hover:bg-accent"
                    data-testid={`from-unit-${unit.replace(/\s+/g, '-').toLowerCase()}`}
                  >
                    {unit}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              type="number"
              placeholder="Enter value"
              value={converter.fromValue}
              onChange={handleFromValueChange}
              className="w-full bg-secondary text-secondary-foreground border border-border"
              data-testid="input-from-value"
            />
          </div>
          
          {/* To Unit */}
          <div className="space-y-4">
            <Label className="block text-sm font-medium">To</Label>
            <Select value={converter.toUnit} onValueChange={handleToUnitChange}>
              <SelectTrigger 
                className="w-full bg-secondary text-secondary-foreground border border-border"
                data-testid="select-to-unit"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border">
                {converter.availableUnits.map((unit) => (
                  <SelectItem 
                    key={unit} 
                    value={unit}
                    className="hover:bg-accent"
                    data-testid={`to-unit-${unit.replace(/\s+/g, '-').toLowerCase()}`}
                  >
                    {unit}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="relative">
              <Input
                type="number"
                placeholder="Result"
                value={converter.toValue}
                readOnly
                className="w-full bg-muted text-foreground border border-border pr-10"
                data-testid="input-to-value"
              />
              {converter.isLoading && (
                <Loader2 className="h-4 w-4 animate-spin absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              )}
            </div>
          </div>
        </div>
        
        {/* Real-time Currency Rate Display */}
        {converter.category === "currency" && converter.lastUpdated && (
          <div className="mt-4 text-sm text-muted-foreground" data-testid="currency-rate-info">
            <i className="fas fa-info-circle mr-1"></i>
            <span>Exchange rate: 1 {converter.fromUnit} = {converter.exchangeRate?.toFixed(6)} {converter.toUnit}</span>
            <br />
            <span>Last updated: {converter.lastUpdated.toLocaleString()}</span>
          </div>
        )}
      </div>
    </div>
  );
}
