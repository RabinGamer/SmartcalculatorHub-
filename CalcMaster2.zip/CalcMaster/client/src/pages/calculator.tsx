import { useState } from "react";
import BasicCalculator from "@/components/calculator/BasicCalculator";
import ScientificCalculator from "@/components/calculator/ScientificCalculator";
import UnitConverter from "@/components/calculator/UnitConverter";
import { GraphingCalculator } from "@/components/calculator/GraphingCalculator";

type CalculatorMode = "basic" | "scientific" | "converter" | "graphing";

export default function CalculatorPage() {
  const [activeMode, setActiveMode] = useState<CalculatorMode>("basic");

  const tabs = [
    { id: "basic", label: "Basic", icon: "fas fa-calculator" },
    { id: "scientific", label: "Scientific", icon: "fas fa-square-root-alt" },
    { id: "converter", label: "Converter", icon: "fas fa-exchange-alt" },
    { id: "graphing", label: "Graphing", icon: "fas fa-chart-line" },
  ] as const;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl sm:text-2xl font-semibold text-foreground">
              Multi Calculator Pro
            </h1>
            <div className="flex items-center space-x-2">
              {/* AdSense Header Slot */}
              <div className="ad-slot w-32 h-8 hidden sm:block">
                Header Ad
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex justify-center space-x-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveMode(tab.id as CalculatorMode)}
                className={`nav-tab flex-1 max-w-xs py-4 px-4 text-center transition-colors border-b-2 border-transparent ${
                  activeMode === tab.id
                    ? "active border-primary text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                data-testid={`tab-${tab.id}`}
              >
                <i className={`${tab.icon} text-xl mb-1 block`}></i>
                <span className="text-sm font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className={`container mx-auto px-4 py-6 ${activeMode === 'graphing' ? 'max-w-7xl' : 'max-w-2xl'}`}>
        {/* AdSense Top Content Slot */}
        <div className="ad-slot w-full h-20 mb-6">
          Top Content Ad - 728x90 or Responsive
        </div>

        {/* Calculator Components */}
        {activeMode === "basic" && <BasicCalculator />}
        {activeMode === "scientific" && <ScientificCalculator />}
        {activeMode === "converter" && <UnitConverter />}
        {activeMode === "graphing" && <GraphingCalculator />}

        {/* AdSense Mid Content Slot */}
        <div className="ad-slot w-full h-24 my-8">
          Mid Content Ad - 728x90 or Responsive
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4 text-foreground">
                Multi Calculator Pro
              </h3>
              <p className="text-muted-foreground text-sm">
                Professional calculator suite with basic, scientific, and unit conversion 
                capabilities. Perfect for students, professionals, and everyday calculations.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-4 text-foreground">Features</h4>
              <ul className="text-muted-foreground text-sm space-y-2">
                <li>• Basic Calculator</li>
                <li>• Scientific Calculator</li>
                <li>• Unit Converter (30+ categories)</li>
                <li>• Graphing Calculator</li>
                <li>• Real-time Currency Conversion</li>
                <li>• Calculation History & Memory</li>
                <li>• Mobile Responsive</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4 text-foreground">Support</h4>
              <div className="ad-slot w-full h-16">
                Footer Ad
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground text-sm">
            <p>&copy; 2024 Multi Calculator Pro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
